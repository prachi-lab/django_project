from django.apps import AppConfig


class StockmgmgtConfig(AppConfig):
    name = 'stockmgmgt'
